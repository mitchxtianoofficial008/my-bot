# MITCH CHRISTIANO — Full WhatsApp Bot

A production-oriented starter for a branded, modular WhatsApp assistant.

## One-time setup

### Windows
Double-click `start.bat`.

### Linux/macOS
Run:
```bash
chmod +x start.sh
./start.sh
```

The setup wizard creates `.env`. Then the bot starts and displays a WhatsApp QR code.

**You personally scan the QR code** using WhatsApp → Linked devices. Never share verification codes or session files.

## Dashboard

In another terminal:
```bash
npm run dashboard
```
Then open `http://localhost:3000` (or the port you selected during setup).

## Main commands

`.menu` `.categories` `.ping` `.alive` `.botinfo` `.time` `.uptime`

`.ai <question>` `.programming <question>`

`.calc 20*5` `.weather Kampala` `.wiki Uganda`

`.groupinfo` `.tagall` `.welcome on` `.promote @user` `.demote @user` `.kick @user`

Reply to an image with `.sticker`

Owner: `.settings` `.broadcast <text>` `.restart`

## Automatic operation

- Persistent WhatsApp session in `session/`
- Persistent statistics/settings in `data/`
- Reconnection after ordinary connection loss
- Windows/Linux startup helpers
- Optional PM2 configuration
- Dockerfile included
- Web dashboard included

For server deployment, keep `session/` on persistent storage.

## Safety and legitimate use

This bot does not include piracy modules for unauthorized downloading/distribution of copyrighted movies, music, software, or other protected material. Media commands are for processing user-provided content and legitimate sources.

## AI

Set `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in `.env` to enable `.ai` and `.programming`. Keep API keys private.
